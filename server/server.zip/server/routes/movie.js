      var express = require('express');
      var mongoose=require("mongoose");
      var router = express.Router();
      var movie = require('../model/movie');

      var loggerTest=function(req,res,next){
        movie.find(function(err,data){
          if (err)res.send(err)
          else{
            console.log("middleware");
            res.send(data)
          }
        })
      }

      router.get('/display', function(req, res, next) {
      var movie=mongoose.model('movieCollection');
      movie.find({},function(err,data){
      if(err)
      {
      res.send(err);
      }
      else
      {
      res.send(data);
      }

      })

      });


      router.post('/add', function(req, res, next) {
      console.log('Inside post');
      var movieVar = new movie(req.body);

      movieVar.save(function (err,data) {
      if(err)
      {
        res.send(err);
      }
      else
      {
        console.log("sent");
          next();

      }

      });
      });


      router.put('/update/:id/:title', function (req, res, next) {
        console.log(req.params.title);
      movie.findOneAndUpdate({imdbID:req.params.id}, {Title: req.params.title},function(err,data){
      console.log('inside update');
      if(err)
      {
      res.send(err);
      }
      else
      {
        console.log("Update Successful");
      next();
      }
      });
      });



      router.delete('/delete', function(req, res, next) {

      var movie=mongoose.model('movieCollection');
      movie.findOneAndRemove({imdbID:req.body.imdbID},function(err,data){
      if(err)
      {
      res.send(err);
      }
      else
      {
      res.send('delete');
      }
      next();
      })

      });

      router.use(loggerTest);
      module.exports = router;
